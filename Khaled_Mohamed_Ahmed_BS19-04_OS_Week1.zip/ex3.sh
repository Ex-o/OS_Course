echo $(date)
sleep 3
echo $(date)
